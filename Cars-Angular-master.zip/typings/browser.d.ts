/// <reference path="browser/ambient/es6-shim/index.d.ts" />
