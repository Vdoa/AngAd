/* Defines the product entity */
export interface IShop {
    name: string;
    location: string;
    logoUrl: string;
    id: number;
}